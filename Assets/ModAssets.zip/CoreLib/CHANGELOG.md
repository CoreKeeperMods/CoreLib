## Changelog
### 2.0.0
- Updated Editor Kit to match with CoreLib 2.0.0
- Added ModCraftingRecipe Drawer
- First version to use ThunderKit

### 1.4.0
- Updated Editor Kit to match with CoreLib 1.4.0
- Updated to Unity 2021.3.14 
- Added Shader fix utility 
- Added Update to V2 button on RuntimeMaterial script

### 1.0.0
- Initial Release
