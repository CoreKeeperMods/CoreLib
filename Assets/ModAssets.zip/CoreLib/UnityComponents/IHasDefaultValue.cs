namespace CoreLib.Components
{
    public interface IHasDefaultValue
    {
        void InitDefaultValues();
    }
}