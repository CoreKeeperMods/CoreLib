﻿using System;
using System.Runtime.InteropServices;
using CoreLib;
using CoreLib.Components;
using PugMod;
using RailLogistics.Components;
using Unity.Collections;
using Unity.Entities;
using UnityEngine;

namespace RailLogistics.UI
{
    public class LocomotiveUI : ItemSlotsUIContainer
    {
        public ButtonUIElement[] speedButtons;
        public FuelIconUI fuelIcon;

        public override int MAX_ROWS => 1;

        public override int MAX_COLUMNS => 1;

        protected override void Awake()
        {
            base.Awake();
            Hide();
        }

        public override void Init()
        {
            if (!initDone)
            {
                visibleRows = MAX_ROWS;
                visibleColumns = MAX_COLUMNS;
                foreach (SlotUIBase slotUIBase in itemSlots)
                {
                    slotUIBase.Init(this);
                }
                initDone = true;
            }
        }

        public void Show()
        {
            Update();
            itemSlotsRoot.SetActive(true);
        }

        public void Hide()
        {
            itemSlotsRoot.SetActive(false);
        }

        public void OnBackwardsClicked()
        {
            SetCurrentSpeed(-1);
        }
        
        public void OnStopClicked()
        {
            SetCurrentSpeed(0); 
        }
        
        public void OnForwardClicked()
        {
            SetCurrentSpeed(1);
        }
        
        public void OnFastForwardClicked()
        {
            SetCurrentSpeed(2);
        }

        public void SetCurrentSpeed(int speed)
        {
            UpdateUI(speed);
            API.Client.SendMessage<RailLogisticsMod>(RailLogisticsMod.RPC_SET_LOCOMOTIVE_SPEED, GetEntity(), speed, 0);
        }

        private void UpdateUI(int speed)
        {
            int buttonIndex = speed + 1;
            for (int i = 0; i < speedButtons.Length; i++)
            {
                if (buttonIndex == i)
                    speedButtons[i].OnSelected();
                else
                    speedButtons[i].OnDeselected();
            }
        }

        private void Update()
        {
            if (!isShowing) return;
            
            LocomotiveCD locomotiveCd = world.EntityManager.GetComponentData<LocomotiveCD>(GetEntity());
            float fuel = locomotiveCd.ticksUntilConsume / (float) locomotiveCd.fuelConsumptionRate;
            fuelIcon.SetFillAmount(fuel);
            UpdateUI(locomotiveCd.targetSpeed);
        }

        private Entity GetEntity()
        {
            InventoryHandler inventoryHandler = GetInventoryHandler();
            return inventoryHandler.entityMonoBehaviour.entity;
        }
    }
}