﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

namespace RailLogistics.UI
{
    public class FuelIconUI : UIelement
    {
        public SpriteRenderer fireIconRenderer;

        public void SetFillAmount(float value)
        {
            value = Math.Clamp(value, 0, 1) * 0.5f;
            fireIconRenderer.size = new Vector2(0.5f, value);
            fireIconRenderer.transform.position = new Vector3(-0.03f, value * 0.5f - 0.25f, 0);
        }
        
        public const string FIRE_ICON_HOVER_DESC = "Mod/FireIconHoverDesc";
        
        public override List<TextAndFormatFields> GetHoverDescription()
        {
            var list = new List<TextAndFormatFields>(1)
            {
                new TextAndFormatFields
                {
                    text = FIRE_ICON_HOVER_DESC
                }
            };
            return list;
        }
    }
}