﻿using System;
using System.Collections.Generic;
using PugTilemap;
using RailLogistics.Components;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;

namespace RailLogistics.Systems
{
    [DisableAutoCreation]
    public class MinecartMoveSystem : PugSimulationSystemBase
    {
        public static bool isEnabled = true;

        public static float accelSpeed = 5f;
        public static float breakSpeed = 3f;
        public static float maxSpeed = 10;
        public static float followDistance = 1;
        public static float separationSpeed = 5;

        private BeginSimulationEntityCommandBufferSystem ecbSystem;

        private EntityQuery minecartQuery;
        private EntityQuery locomotiveQuery;
        private EntityQuery linkedMinecartQuery;

        private MinecartMoveUpdateJob moveUpdateJob;
        private LocomotiveUpdateJob locomotiveUpdateJob;
        private LinkedMinecartUpdateJob linkedMinecartUpdateJob;

        protected override void OnCreateForCompiler()
        {
            base.OnCreateForCompiler();
            ecbSystem = World.GetExistingSystem<BeginSimulationEntityCommandBufferSystem>();
            minecartQuery = GetEntityQuery(
                ComponentType.ReadWrite<MoveMinecartStateCD>(),
                ComponentType.ReadWrite<Translation>(),
                ComponentType.ReadWrite<MinecartCD>(),
                ComponentType.ReadWrite<DirectionCD>(),
                ComponentType.ReadOnly<MinecartInputCD>()
            );

            locomotiveQuery = GetEntityQuery(
                ComponentType.ReadOnly<DirectionCD>(),
                ComponentType.ReadWrite<LocomotiveCD>(),
                ComponentType.ReadWrite<ContainedObjectsBuffer>()
            );

            linkedMinecartQuery = GetEntityQuery(
                ComponentType.ReadOnly<MinecartJointCD>(),
                ComponentType.ReadWrite<MinecartInputCD>()
            );

            moveUpdateJob = new MinecartMoveUpdateJob();
            locomotiveUpdateJob = new LocomotiveUpdateJob();
            linkedMinecartUpdateJob = new LinkedMinecartUpdateJob();
            
            JobEntityBatchExtensions.EarlyJobInit<MinecartMoveUpdateJob>();
        }

        protected override void OnUpdate()
        {
            if (!isEnabled) return;
            locomotiveUpdateJob.locomotiveFromEntity = GetComponentDataFromEntity<LocomotiveCD>();
            locomotiveUpdateJob.inputFromEntity = GetComponentDataFromEntity<MinecartInputCD>();
            locomotiveUpdateJob.directionFromEntity = GetComponentDataFromEntity<DirectionCD>(true);
            locomotiveUpdateJob.objectsFromEntity = GetBufferFromEntity<ContainedObjectsBuffer>();
            locomotiveUpdateJob.entities = locomotiveQuery.ToEntityArrayAsync(Allocator.TempJob, out JobHandle queryHandle);

            JobHandle locomotiveJobHandle = IJobExtensions.Schedule(locomotiveUpdateJob, queryHandle);

            linkedMinecartUpdateJob.jointFromEntity = GetComponentDataFromEntity<MinecartJointCD>(true);
            linkedMinecartUpdateJob.inputFromEntity = GetComponentDataFromEntity<MinecartInputCD>();
            linkedMinecartUpdateJob.translationFromEntity = GetComponentDataFromEntity<Translation>(true);
            linkedMinecartUpdateJob.minecartFromEntity = GetComponentDataFromEntity<MinecartCD>(true);
            linkedMinecartUpdateJob.entities = linkedMinecartQuery.ToEntityArrayAsync(Allocator.TempJob, out JobHandle query1Handle);
            
            JobHandle linkedMinecartJobHandle = IJobExtensions.Schedule(linkedMinecartUpdateJob, query1Handle);
            
            EntityCommandBuffer ecb = ecbSystem.CreateCommandBuffer();

            moveUpdateJob.accessor = CreateTileAccessor();
            moveUpdateJob.ecb = ecb;
            moveUpdateJob.deltaTime = Time.DeltaTime;
            moveUpdateJob.translationFromEntity = GetComponentDataFromEntity<Translation>(true);
            moveUpdateJob.minecartFromEntity = GetComponentDataFromEntity<MinecartCD>(true);
            moveUpdateJob.directionFromEntity = GetComponentDataFromEntity<DirectionCD>(true);
            moveUpdateJob.moveMinecartFromEntity = GetComponentDataFromEntity<MoveMinecartStateCD>(true);
            moveUpdateJob.inputFromEntity = GetComponentDataFromEntity<MinecartInputCD>(true);
            moveUpdateJob.entityTypeHandle = GetEntityTypeHandle();

            JobHandle setupHandle = JobHandle.CombineDependencies(locomotiveJobHandle, linkedMinecartJobHandle);
            Dependency = JobEntityBatchExtensions.Schedule(moveUpdateJob, minecartQuery, setupHandle);
            Dependency.Complete();
            ecbSystem.AddJobHandleForProducer(Dependency);
            base.OnUpdate();
        }

        
        public struct MinecartMoveUpdateJob : IJobEntityBatch
        {
            public float deltaTime;
            public EntityTypeHandle entityTypeHandle;
            public EntityCommandBuffer ecb;

            public ComponentDataFromEntity<Translation> translationFromEntity;
            public ComponentDataFromEntity<MinecartCD> minecartFromEntity;
            public ComponentDataFromEntity<DirectionCD> directionFromEntity;
            public ComponentDataFromEntity<MoveMinecartStateCD> moveMinecartFromEntity;
            public ComponentDataFromEntity<MinecartInputCD> inputFromEntity;

            public TileAccessor accessor;

            public void Execute(ArchetypeChunk batchInChunk, int batchIndex)
            {
                NativeArray<Entity> entities = batchInChunk.GetNativeArray(entityTypeHandle);
                foreach (Entity entity in entities)
                {
                    UpdateMinecartState(entity);
                }
            }

            public void UpdateMinecartState(Entity entity)
            {
                var minecart = minecartFromEntity[entity];
                var direction = directionFromEntity[entity];
                var minecartState = moveMinecartFromEntity[entity];
                var minecartInput = inputFromEntity[entity];

                var targetDirection = minecartInput.targetDirection;
                var targetAcceleration = minecartInput.targetAcceleration;

                var position = translationFromEntity[entity].Value;
                int2 velocityDir = direction.direction.FloorToInt2();
                float velocity = minecart.currentSpeed;
                var margin = 0.1f + 0.35f * math.clamp(minecart.currentSpeed * 0.001f, 0f, 1f);

                if (minecartState.hasAPlannedTurningPointSet)
                {
                    float2 rhs = new float2(position.x, position.z);
                    int2 lhs = math.normalizesafe(minecartState.nextPlannedTurningWorldTilePos - rhs, float2.zero).RoundToInt2();
                    if ((math.any(lhs != minecartState.vectorToNextPlannedTurningWorldTilePos) && math.any(lhs != int2.zero)) ||
                        accessor.GetTop(position.RoundToInt2()).tileType != TileType.rail)
                    {
                        velocityDir = minecartState.vectorToNextPlannedTurningWorldTilePos;
                        position = new float3(minecartState.nextPlannedTurningWorldTilePos.x, 0f, minecartState.nextPlannedTurningWorldTilePos.y);
                    }
                }


                if (accessor.GetTop(position.RoundToInt2()).tileType != TileType.rail)
                {
                    minecart.currentSpeed = 0;
                    ecb.SetComponent(entity, new Translation { Value = position });
                    ecb.SetComponent(entity, minecart);
                    ecb.SetComponent(entity, direction);
                    return;
                }

                if (math.any(minecartState.lastTurnedTile != position.RoundToInt2()))
                {
                    minecartState.canTurn = true;
                }

                int2 nextDirection = int2.zero;
                List<int2> directions = new List<int2>();
                Direction[] allDirections = Direction.allFourClockwise;
                for (int i = 0; i < allDirections.Length; i++)
                {
                    float2 directionVec = (float2)allDirections[i].i2 * (0.5f + margin);
                    TileCD surfaceTileAt = accessor.GetTop((int2)math.round(directionVec + position.xz));
                    bool straight = math.any(velocityDir != int2.zero) && math.dot(allDirections[i].i2, velocityDir) == 0;
                    if (surfaceTileAt.tileType == TileType.rail && (!straight || minecartState.canTurn))
                    {
                        directions.Add(allDirections[i].i2);
                        int2 potentialDirection = int2.zero;
                        if ((allDirections[i].id == Direction.Id.forward && targetDirection.y > 0f) ||
                            (allDirections[i].id == Direction.Id.back && targetDirection.y < 0f))
                        {
                            potentialDirection = new int2(0, targetDirection.y);
                        }
                        else if ((allDirections[i].id == Direction.Id.right && targetDirection.x > 0f) ||
                                 (allDirections[i].id == Direction.Id.left && targetDirection.x < 0f))
                        {
                            potentialDirection = new int2(targetDirection.x, 0);
                        }

                        if (math.length(nextDirection) < math.length(potentialDirection))
                        {
                            nextDirection = potentialDirection;
                        }
                    }
                    else if (surfaceTileAt.tileType != TileType.rail)
                    {
                        if (allDirections[i].id == Direction.Id.forward && position.z > math.round(position.z))
                        {
                            position.z = math.round(position.z);
                        }
                        else if (allDirections[i].id == Direction.Id.back && position.z < math.round(position.z))
                        {
                            position.z = math.round(position.z);
                        }
                        else if (allDirections[i].id == Direction.Id.right && position.x > math.round(position.x))
                        {
                            position.x = math.round(position.x);
                        }
                        else if (allDirections[i].id == Direction.Id.left && position.x < math.round(position.x))
                        {
                            position.x = math.round(position.x);
                        }
                    }
                }

                nextDirection = math.normalizesafe(nextDirection, float2.zero).RoundToInt2();
                bool directionZero = math.all(nextDirection == int2.zero);

                if (velocity < 80f)
                {
                    int2 newDirection = int2.zero;
                    bool isMoving = false;
                    if (!directionZero)
                    {
                        newDirection = velocityDir;
                        isMoving = true;
                    }
                    else if (math.length(nextDirection) > 0f)
                    {
                        Direction directionVec = Direction.FromVector(math.normalizesafe(nextDirection), 0f);
                        float2 positionInt2 = position.xz;
                        float2 turnDirection1 = directionVec.nextClockwise.f2 * 0.5f;
                        int2 turnPosition1 = (positionInt2 + turnDirection1).RoundToInt2();
                        int2 turnPosition1Int = (positionInt2 + turnDirection1 + directionVec.i2).RoundToInt2();
                        float2 turnDirection2 = directionVec.nextCounterClockwise.f2 * 0.49f;
                        int2 turnPosition2 = (positionInt2 + turnDirection2).RoundToInt2();
                        int2 turnPosition2Int = (positionInt2 + turnDirection2 + directionVec.i2).RoundToInt2();

                        if (accessor.GetTop(turnPosition1).tileType == TileType.rail &&
                            accessor.GetTop(turnPosition1Int).tileType == TileType.rail)
                        {
                            newDirection = turnPosition1;
                            isMoving = true;
                            nextDirection = directionVec.i2;
                        }
                        else if (accessor.GetTop(turnPosition2).tileType == TileType.rail &&
                                 accessor.GetTop(turnPosition2Int).tileType == TileType.rail)
                        {
                            newDirection = turnPosition2;
                            isMoving = true;
                            nextDirection = directionVec.i2;
                        }
                    }

                    if (isMoving)
                    {
                        bool isXAxis = math.abs(nextDirection.x) > 0f;
                        if (((isXAxis && math.abs(newDirection.y - velocityDir.y) > margin) ||
                             (!isXAxis && math.abs(newDirection.x - velocityDir.x) > margin)) &&
                            math.distance(velocityDir, newDirection) >= margin)
                        {
                            nextDirection = math.normalizesafe(
                                (isXAxis ? new float2(velocityDir.x, newDirection.y) : new float2(newDirection.x, velocityDir.y)) - velocityDir,
                                float2.zero).RoundToInt2();
                            directionZero = false;
                        }
                    }
                }

                bool isDirectionTangential = !directionZero && math.any(velocityDir != float2.zero) && math.dot(nextDirection, velocityDir) == 0;
                if (!directionZero && isDirectionTangential && math.distance(velocityDir, velocityDir) >= margin)
                {
                    nextDirection = int2.zero;
                    directionZero = true;
                }

                float accelerateStrength = 0f;
                int2 openDir = int2.zero;
                if (directionZero)
                {
                    if (velocity > 0f)
                    {
                        bool canMove = false;
                        foreach (int2 dir in directions)
                        {
                            if (math.all(velocityDir == dir))
                            {
                                openDir = dir;
                                canMove = true;
                                break;
                            }
                        }

                        if (!canMove)
                        {
                            foreach (int2 dir in directions)
                            {
                                if (math.any(velocityDir != int2.zero) && math.dot(dir, velocityDir) == 0)
                                {
                                    if (canMove)
                                    {
                                        canMove = false;
                                        break;
                                    }

                                    openDir = dir;
                                    canMove = true;
                                }
                            }
                        }

                        if (!canMove)
                        {
                            openDir = int2.zero;
                        }
                        else if (velocity > 200f)
                        {
                            accelerateStrength = accelSpeed * targetAcceleration * deltaTime;
                        }
                    }
                }
                else
                {
                    openDir = nextDirection;
                    accelerateStrength = accelSpeed * targetAcceleration * deltaTime;
                }

                if (math.any(openDir != int2.zero) && math.any(velocityDir != int2.zero) && math.dot(openDir, velocityDir) == 0)
                {
                    minecartState.canTurn = false;
                    minecartState.lastTurnedTile = position.RoundToInt2();
                }

                float breakingStrength;

                if (minecartInput.applyBreaks && Math.Abs(minecart.currentSpeed) > 0.01f)
                {
                    breakingStrength = accelSpeed * deltaTime;
                    minecart.isBreaking = true;
                }
                else
                {
                    breakingStrength = 0.02f;
                    minecart.isBreaking = false;
                }

                breakingStrength = math.clamp(breakingStrength, 0f, minecart.currentSpeed);
                if (Math.Abs(minecartInput.targetSpeed) > 0)
                {
                    minecart.currentSpeed = minecartInput.targetSpeed;
                }
                else
                {
                    minecart.currentSpeed = math.clamp(minecart.currentSpeed + accelerateStrength - breakingStrength, 0f, minecart.maxSpeed);
                }

                if (math.all(openDir == int2.zero))
                {
                    minecart.currentSpeed = 0;
                }
                
                if (math.length(openDir) > 0)
                {
                    direction.direction = openDir.ToFloat3();
                }

                position += openDir.ToFloat3() * minecart.currentSpeed * deltaTime;

                velocityDir = openDir;
                if (math.abs(openDir.x) > 0 && math.length(position.z - math.round(position.z)) <= margin)
                {
                    position.z = math.round(position.z);
                }
                else if (math.abs(openDir.y) > 0 && math.length(position.x - math.round(position.x)) <= margin)
                {
                    position.x = math.round(position.x);
                }

                ecb.SetComponent(entity, new Translation
                {
                    Value = position
                });
                int2 roundPos = new int2((int)math.round(position.x), (int)math.round(position.z));
                minecartState.nextPlannedTurningWorldTilePos = roundPos;
                minecartState.hasAPlannedTurningPointSet = false;

                if (math.any(velocityDir != int2.zero))
                {
                    for (int j = 0; j <= 2; j++)
                    {
                        int2 nextPos = roundPos + velocityDir * j;
                        if (accessor.GetTop(nextPos).tileType != TileType.rail)
                        {
                            break;
                        }

                        bool planATurn = false;
                        for (int k = 0; k < allDirections.Length; k++)
                        {
                            float2 tileDirection = (float2)allDirections[k].i2 * (0.5f + margin);
                            int2 tilePosition = (int2)math.round(nextPos + tileDirection);
                            TileCD surfaceTile = accessor.GetTop(tilePosition);
                            bool isTangential = math.any(velocityDir != int2.zero) && math.dot(allDirections[k].i2, velocityDir) == 0;
                            int2 directionVec = math.normalizesafe(nextPos - position.RoundToInt2(), float2.zero).RoundToInt2();
                            bool sameAsVelocity = math.any(velocityDir != int2.zero) && math.any(directionVec != int2.zero) &&
                                                  math.all(velocityDir == directionVec);
                            if (surfaceTile.tileType == TileType.rail && isTangential && minecartState.canTurn && sameAsVelocity)
                            {
                                Direction.Id id = allDirections[k].id;
                                //if ((id == Direction.Id.forward && targetDirection.y > 0f) || (id == Direction.Id.back && targetDirection.y < 0f) ||
                                //    (id == Direction.Id.right && targetDirection.x > 0f) || (id == Direction.Id.left && targetDirection.x < 0f))
                                //{
                                planATurn = true;
                                break;
                                //}
                            }
                        }

                        minecartState.nextPlannedTurningWorldTilePos = nextPos;
                        minecartState.vectorToNextPlannedTurningWorldTilePos = math.normalizesafe(nextPos - position.ToFloat2(), float2.zero).RoundToInt2();
                        if (planATurn)
                        {
                            break;
                        }
                    }

                    minecartState.hasAPlannedTurningPointSet = true;
                }

                ecb.SetComponent(entity, minecartState);
                ecb.SetComponent(entity, minecart);
                ecb.SetComponent(entity, direction);
            }
        }

        public struct LocomotiveUpdateJob : IJob
        {
            public NativeArray<Entity> entities;

            public ComponentDataFromEntity<DirectionCD> directionFromEntity;
            public ComponentDataFromEntity<LocomotiveCD> locomotiveFromEntity;
            public ComponentDataFromEntity<MinecartInputCD> inputFromEntity;
            public BufferFromEntity<ContainedObjectsBuffer> objectsFromEntity;


            public void Execute()
            {
                foreach (Entity entity in entities)
                {
                    UpdateLocomotiveLogic(entity);
                }

                entities.Dispose();
            }

            private void UpdateLocomotiveLogic(Entity entity)
            {
                LocomotiveCD locomotive = locomotiveFromEntity[entity];
                DynamicBuffer<ContainedObjectsBuffer> items = objectsFromEntity[entity];
                if (items.Length <= 0) return;

                ContainedObjectsBuffer item = items[0];
                bool changed = false;

                if (locomotive.ticksUntilConsume <= 0 &&
                    item.objectData.objectID == ObjectID.Wood &&
                    item.objectData.amount > 0)
                {
                    item.objectData.amount -= 1;
                    if (item.objectData.amount <= 0)
                    {
                        item.objectData.objectID = ObjectID.None;
                    }

                    locomotive.ticksUntilConsume = locomotive.fuelConsumptionRate;
                    items[0] = item;
                    changed = true;
                }

                if (locomotive.ticksUntilConsume > 0 &&
                    locomotive.targetSpeed != 0)
                {
                    locomotive.ticksUntilConsume--;
                    DirectionCD direction = directionFromEntity[entity];
                    inputFromEntity[entity] = new MinecartInputCD
                    {
                        targetDirection = direction.direction.RoundToInt2(),
                        targetAcceleration = locomotive.acceleration * locomotive.targetSpeed,
                        applyBreaks = false
                    };
                    changed = true;
                }
                else
                {
                    inputFromEntity[entity] = new MinecartInputCD()
                    {
                        applyBreaks = true
                    };
                }

                if (changed)
                    locomotiveFromEntity[entity] = locomotive;
            }
        }

        public struct LinkedMinecartUpdateJob : IJob
        {
            public NativeArray<Entity> entities;

            public ComponentDataFromEntity<Translation> translationFromEntity;
            public ComponentDataFromEntity<MinecartInputCD> inputFromEntity;
            public ComponentDataFromEntity<MinecartJointCD> jointFromEntity;
            public ComponentDataFromEntity<MinecartCD> minecartFromEntity;

            public void Execute()
            {
                foreach (Entity entity in entities)
                {
                    UpdateJointLogic(entity);
                }

                entities.Dispose();
            }

            private void UpdateJointLogic(Entity entity)
            {
                MinecartJointCD jointCd = jointFromEntity[entity];
                if (minecartFromEntity.HasComponent(jointCd.parentMinecart))
                {
                    Translation ourTranslation = translationFromEntity[entity];
                    Translation parentTranslation = translationFromEntity[jointCd.parentMinecart];
                    MinecartCD parentMinecart = minecartFromEntity[jointCd.parentMinecart];

                    float2 diff = parentTranslation.Value.xz - ourTranslation.Value.xz;
                    float distance = math.length(diff);

                    int2 direction = int2.zero;
                    float2 absDiff = math.abs(diff);
                    if (absDiff.x > absDiff.y)
                    {
                        direction = new int2(Math.Sign(diff.x), 0);
                    }else if (absDiff.y > absDiff.x)
                    {
                        direction = new int2(0, Math.Sign(diff.y));
                    }

                    float speed = 0;
                    if (Math.Abs(parentMinecart.currentSpeed) < 0.1f)
                    {
                        float distDiff = distance - followDistance;
                        if (Math.Abs(distDiff) > 0.05f) 
                            speed = distDiff * separationSpeed;
                    }
                    else
                    {
                        float multiplier = 1 / (1 + followDistance - distance);
                        speed =  parentMinecart.currentSpeed * multiplier;
                    }

                    inputFromEntity[entity] = new MinecartInputCD()
                    {
                        targetDirection = direction,
                        targetSpeed = speed,
                        applyBreaks = false
                    };
                }
                else
                {
                    inputFromEntity[entity] = new MinecartInputCD()
                    {
                        applyBreaks = true
                    };
                }
            }
        }
    }
}