﻿using System;
using CoreLib.Components;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

namespace RailLogistics.Components
{
    public struct MinecartInputCD : IComponentData
    {
        public int2 targetDirection;
        public bool applyBreaks;
        public float targetAcceleration;
        public float targetSpeed;
    }
    
    public class MinecartInputCDAuthoring : MonoBehaviour
    {
    }
    
    public class MinecartInputCDConverter : SingleAuthoringComponentConverter<MinecartInputCDAuthoring>
    {
        protected override void Convert(MinecartInputCDAuthoring authoring)
        {
            AddComponentData(new MinecartInputCD());
        }
    }
}