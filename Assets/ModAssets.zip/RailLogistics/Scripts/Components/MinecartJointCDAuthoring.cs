﻿using System;
using CoreLib.Components;
using Unity.Entities;
using UnityEngine;

namespace RailLogistics.Components
{
    public struct MinecartJointCD : IComponentData
    {
        public Entity parentMinecart;
    }
    
    public class MinecartJointCDAuthoring : MonoBehaviour
    {
    }
    
    public class MinecartJointCDConverter : SingleAuthoringComponentConverter<MinecartJointCDAuthoring>
    {
        protected override void Convert(MinecartJointCDAuthoring authoring)
        {
            AddComponentData(new MinecartJointCD());
        }
    }
}