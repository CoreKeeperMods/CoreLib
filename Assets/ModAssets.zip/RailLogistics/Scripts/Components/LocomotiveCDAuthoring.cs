﻿using System;
using CoreLib.Components;
using Unity.Entities;
using Unity.NetCode;
using UnityEngine;

namespace RailLogistics.Components
{
    [GhostComponent]
    public struct LocomotiveCD : IComponentData
    {
        [GhostField]
        public int targetSpeed;
        
        public float maxSpeed;
        public float acceleration;
        public int fuelConsumptionRate;
        [GhostField]
        public int ticksUntilConsume;
    }
    
    public class LocomotiveCDAuthoring : MonoBehaviour
    {
        public float maxSpeed;
        public float acceleration;
        public int fuelConsumptionRate;
    }
    
    public class LocomotiveCDConverter : SingleAuthoringComponentConverter<LocomotiveCDAuthoring>
    {
        protected override void Convert(LocomotiveCDAuthoring authoring)
        {
            AddComponentData(new LocomotiveCD()
            {
                maxSpeed = authoring.maxSpeed,
                acceleration = authoring.acceleration,
                fuelConsumptionRate = authoring.fuelConsumptionRate
            });
        }
    }
}