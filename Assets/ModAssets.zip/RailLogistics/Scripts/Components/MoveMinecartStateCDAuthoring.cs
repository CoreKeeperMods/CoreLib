﻿using Unity.Entities;
using Unity.Mathematics;
using Unity.NetCode;
using UnityEngine;

namespace RailLogistics.Components
{
    public struct MoveMinecartStateCD : IComponentData
    {
        public int2 nextPlannedTurningWorldTilePos;
        public int2 vectorToNextPlannedTurningWorldTilePos;
        public int2 lastTurnedTile;
        
        public bool hasAPlannedTurningPointSet;
        public bool canTurn;
    }
    
    [DisallowMultipleComponent]
    public class MoveMinecartStateCDAuthoring : MonoBehaviour
    {
    }
    
    public class MoveMinecartStateCDConverter : SingleAuthoringComponentConverter<MoveMinecartStateCDAuthoring>
    {
        protected override void Convert(MoveMinecartStateCDAuthoring authoring)
        {
            AddComponentData(new MoveMinecartStateCD()
            {
                canTurn = true
            });
        }
    }
}