﻿namespace RailLogistics.Entities
{
    public class ChestMinecart : ModMinecart
    {
        public InventoryHandler inventoryHandler;
        
        public override void OnOccupied()
        {
            base.OnOccupied();
            inventoryHandler = new InventoryHandler(this, world);
        }
        
        public override void OnFree()
        {
            Dispose();
            base.OnFree();
        }

        public override void OnDestroy()
        {
            Dispose();
            base.OnDestroy();
        }

        private void Dispose()
        {
            if (inventoryHandler != null)
            {
                inventoryHandler.Dispose();
                inventoryHandler = null;
            }
        }
        
        public override void ManagedLateUpdate()
        {
            base.ManagedLateUpdate();
            if (!entityExist)
            {
                return;
            }
            inventoryHandler.Update();
        }
        
        public override void Use()
        {
            interactable.currentPlayer.SetActiveInventoryHandler(inventoryHandler);
            Manager.ui.OnChestInventoryOpen();
        }
        
        public override void OnPlayerLeft()
        {
            if (interactable == null) return;
            var player = interactable.currentPlayer;
            if (player != null && player.activeInventoryHandler == inventoryHandler)
            {
                Manager.ui.HideAllInventoryAndCraftingUI();
                player.SetActiveInventoryHandler(null);
            }
        }

        protected override void OnDeath()
        {
            base.OnDeath();
            Manager.effects.PlayPuff(PuffID.DirtBlockDust, transform.position, 5);
        }
    }
}