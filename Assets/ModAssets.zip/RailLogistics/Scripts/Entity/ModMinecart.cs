using CoreLib.Util.Extensions;
using Unity.Mathematics;
using UnityEngine;

namespace RailLogistics.Entities
{
    public class ModMinecart : EntityMonoBehaviour
    {
        public const float MAX_ANIM_SPEED = 1.6f;
        public const float QUICK_TURN_SPEED_THRESHOLD = 1f;
        public const float QUICK_STOP_SPEED_DIFF = 0.6f;
        
        public float previousAnimSpeed;
        public Vector3 previousOrientation;
        public SfxUnityInspectorFriendlyID loopSound;
        public SfxUnityInspectorFriendlyID loopBrakeSound;
        public PoolableAudioSource minecartAudioLoop;
        public PoolableAudioSource brakeAudioLoop;
        public ParticleSystem brakeParticles1;
        public ParticleSystem brakeParticles2;

        public virtual void Use()
        {
            
        }

        public virtual void OnPlayerLeft()
        {
            
        }

        protected override bool updateAnimOrientation => true;
        protected override bool updateAnimMovement => true;
        protected override bool updateAnimMovementSpeed => true;

        protected override float GetAnimSpeed()
        {
            MinecartCD minecartCd = world.EntityManager.GetComponentData<MinecartCD>(entity);
            float speed = minecartCd.currentSpeed / minecartCd.maxSpeed * 2f;

            if (speed > 0.01f)
            {
                speed = math.max(speed, 0.3f);
            }

            return speed;
        }

        public override void OnOccupied()
        {
            base.OnOccupied();
            previousAnimSpeed = GetAnimSpeed();
        }

        protected override Vector3 GetAnimOrientationVec3()
        {
            DirectionCD directionCd = world.EntityManager.GetComponentData<DirectionCD>(entity);

            if (math.length(directionCd.direction) > 0) 
                return directionCd.direction.ToVector3();
            
            return EntityUtility.GetComponentData<AnimationOrientationCD>(entity, world).facingDirection.vec3;
        }

        public override void ManagedLateUpdate()
        {
            base.ManagedLateUpdate();
            if (!entityExist)
            {
                return;
            }

            float animSpeed = GetAnimSpeed();
            Vector3 animOrientationVec = GetAnimOrientationVec3();
            MinecartCD minecartCd = world.EntityManager.GetComponentData<MinecartCD>(entity);
            bool isBreaking = minecartCd.isBreaking;

            if (animSpeed > 0)
            {
                if (minecartAudioLoop == null)
                {
                    minecartAudioLoop = AudioManager.SfxFollowTransform(Manager.audio.InspectorFriendlySfxIDToSfxID(loopSound), transform, 0f,
                        1f, 0f, false, AudioManager.MixerGroupEnum.EFFECTS, true, true, true, 16f, 10f, true);
                }

                if (brakeAudioLoop == null)
                {
                    brakeAudioLoop = AudioManager.SfxFollowTransform(Manager.audio.InspectorFriendlySfxIDToSfxID(loopBrakeSound), transform, 0f,
                        1f, 0f, false, AudioManager.MixerGroupEnum.EFFECTS, true, true, true, 16f, 10f, true);
                }
            }
            else
            {
                if (minecartAudioLoop != null)
                {
                    minecartAudioLoop.FadeOutAndStop();
                    minecartAudioLoop = null;
                }

                if (brakeAudioLoop != null)
                {
                    brakeAudioLoop.FadeOutAndStop();
                    brakeAudioLoop = null;
                }
            }

            if (minecartAudioLoop)
            {
                minecartAudioLoop.SetVolume(animSpeed / 1.6f);
            }

            Breaking(isBreaking, animSpeed);

            bool flag3 = Direction.FromVector(animOrientationVec, 0f) == Direction.FromVector(previousOrientation, 0f) ||
                         Direction.FromVector(animOrientationVec, 0f) == Direction.zero;
            if (previousAnimSpeed - animSpeed > QUICK_STOP_SPEED_DIFF && flag3)
            {
                Crash();
            }

            if (Direction.FromVector(animOrientationVec, 0f) != Direction.FromVector(previousOrientation, 0f) &&
                animSpeed > QUICK_TURN_SPEED_THRESHOLD)
            {
                QuickTurn();
            }

            previousAnimSpeed = animSpeed;
            previousOrientation = animOrientationVec;
        }

        private void Breaking(bool isBreaking, float animSpeed)
        {
            if (isBreaking)
            {
                if (!brakeParticles1.isPlaying)
                {
                    brakeParticles1.Play();
                    brakeParticles2.Play();
                }

                if (brakeAudioLoop)
                {
                    brakeAudioLoop.SetVolume(animSpeed / 1.6f);
                }
            }
            else
            {
                brakeParticles1.Stop();
                brakeParticles2.Stop();
                if (brakeAudioLoop)
                {
                    brakeAudioLoop.SetVolume(0f);
                }
            }
        }

        private void Crash()
        {
            EntityUtility.PlayEffectEventClient(new EffectEventCD
            {
                effectID = EffectID.MinecartCrash,
                entity = entity
            });
        }

        private void QuickTurn()
        {
            EntityUtility.PlayEffectEventClient(new EffectEventCD
            {
                effectID = EffectID.MinecartQuickTurn,
                entity = entity
            });
        }
    }
}