﻿
namespace RailLogistics.Entities
{
    public class Locomotive : ChestMinecart
    {
        public override void Use()
        {
            interactable.currentPlayer.SetActiveInventoryHandler(inventoryHandler);
            RailLogisticsMod.OpenLocomotiveUI();
        }
    }
}