﻿using HarmonyLib;
using Unity.Collections;
using UnityEngine;

namespace RailLogistics.Patches
{
    [HarmonyPatch]
    public class UIManager_Patch
    {
        [HarmonyPatch(typeof(UIManager), nameof(UIManager.Init))]
        [HarmonyPostfix]
        public static void OnInit(UIManager __instance)
        {
            var UITransform = __instance.chestInventoryUI.transform.parent;
            RailLogisticsMod.locomotiveUI = Object.Instantiate(RailLogisticsMod.locomotiveUIPrefab, UITransform);
            RailLogisticsMod.locomotiveUI.transform.localPosition = new Vector3(5, 5, 0);
        }
        
        [HarmonyPatch(typeof(UIManager), nameof(UIManager.HideAllInventoryAndCraftingUI))]
        [HarmonyPostfix]
        public static void OnHide()
        {
            RailLogisticsMod.locomotiveUI.Hide();
        }
    }
}