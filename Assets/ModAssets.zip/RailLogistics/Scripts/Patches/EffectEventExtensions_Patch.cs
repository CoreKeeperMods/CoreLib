﻿using HarmonyLib;
using RailLogistics.Components;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;

namespace RailLogistics.Patches
{
    [HarmonyPatch]
    public static class EffectEventExtensions_Patch
    {

        [HarmonyPatch(typeof(EffectEventExtensions), nameof(EffectEventExtensions.PlayEffect))]
        [HarmonyPrefix]
        public static bool OnPlayEffect(EffectEventCD effectEvent)
        {
            if (effectEvent.effectID != EffectID.MinecartCrash &&
                effectEvent.effectID != EffectID.MinecartQuickTurn) return true;
            
            Entity entity = effectEvent.entity;
            EntityMonoBehaviour entityMono = Manager.memory.GetEntityMono(entity);
            var entityManager = entityMono.world.EntityManager;
            if (entityManager.HasComponent<MoveMinecartStateCD>(entity))
            {
                if (effectEvent.effectID == EffectID.MinecartCrash)
                {
                    Vector3 position = entityManager.GetComponentData<Translation>(entity).Value;
                    Manager.effects.PlayPuff(PuffID.DirtBlockDust, position, 20);
                    Manager.effects.PlayPuff(PuffID.Sparks, position, 10);
                    AudioManager.Sfx(SfxID.metalImpact, position, 0.8f, 0.8f, 0.1f, false, AudioManager.MixerGroupEnum.EFFECTS, true);
                    entityMono.animator.SetTrigger(AnimID.takeDamage);
                }
                else if (effectEvent.effectID == EffectID.MinecartQuickTurn)
                {
                    Vector3 position = entityManager.GetComponentData<Translation>(entity).Value;
                    Manager.effects.PlayPuff(PuffID.DirtBlockDust, position, 5);
                    Manager.effects.PlayPuff(PuffID.Sparks, position, 4);
                    AudioManager.Sfx(SfxID.metalImpactSmall, position, 0.5f, 0.55f, 0.1f, false, AudioManager.MixerGroupEnum.EFFECTS, true);
                }
                return false;
            }
            return true;
        }
    }
}