﻿using System;
using CoreLib.Extensions;
using HarmonyLib;
using PlayerCommand;
using RailLogistics.Components;
using Unity.Collections;
using Unity.Entities;

namespace RailLogistics.Patches
{
    [HarmonyPatch]
    public static class PlayerCommandServerSystem_Patch
    {
        [HarmonyPatch(typeof(ServerSystem), "OnUpdate")]
        [HarmonyPrefix]
        public static void OnServerUpdate(ServerSystem __instance)
        {
            try
            {
                NativeArray<Entity> entities = __instance.GetField<EntityQuery>("_rpcQuery").ToEntityArray(Allocator.Temp);

                foreach (Entity entity in entities)
                {
                    Rpc component = __instance.EntityManager.GetComponentData<Rpc>(entity);
                    if (component.command == (Command)200)
                    {
                        __instance.EntityManager.SetComponentData(component.entity0, new MinecartJointCD()
                        {
                            parentMinecart = component.entity1
                        });

                        __instance.EntityManager.DestroyEntity(entity);
                    }
                }
            }
            catch (Exception e)
            {
                Logger.LogWarning($"Failed to handle my messages: \n{e}");
            }
        }

        public static void LinkMinecarts(this ClientSystem clientSystem, Entity target, Entity parent)
        {
            clientSystem.GetField<NativeQueue<Rpc>>("rpcQueue").Enqueue(new Rpc
            {
                command = (Command)200,
                entity0 = target,
                entity1 = parent
            });
        }
    }
}