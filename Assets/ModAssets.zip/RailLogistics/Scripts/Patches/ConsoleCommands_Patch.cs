﻿using HarmonyLib;

namespace RailLogistics.Patches
{
    [HarmonyPatch]
    public static class ConsoleCommands_Patch
    {
        [HarmonyPatch(typeof(ConsoleCommands), "ObjectIsValidToSpawn")]
        [HarmonyPostfix]
        public static void ObjectIsValidToSpawn(ref bool __result)
        {
            __result = true;
        }
    }
}