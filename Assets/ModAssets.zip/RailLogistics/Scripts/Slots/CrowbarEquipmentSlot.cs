﻿using System.Reflection;
using CoreLib.Submodules.Equipment;
using RailLogistics.Components;
using RailLogistics.Patches;
using Unity.Entities;


namespace RailLogistics.Slots
{
    public class CrowbarEquipmentSlot : EquipmentSlot, IModEquipmentSlot
    {
        public const string CrowbarObjectType = "RailLogistics:Crowbar";
        
        protected override EquipmentSlotType slotType => EquipmentSlotModule.GetEquipmentSlotType<CrowbarEquipmentSlot>();

        private Entity lastEntity;

        public override void HandleInput(bool interactPressed, bool interactReleased, bool secondInteractPressed, bool secondInteractReleased,
            bool interactIsHeldDown,
            bool secondInteractIsHeldDown)
        {
            if (!interactPressed && !secondInteractPressed) return;

            Entity selectedEntity = Entity.Null;
            if (slotOwner.currentInteractableObject != null)
            {
                var entityMono = slotOwner.currentInteractableObject.entityMono;
                if (entityMono != null)
                    selectedEntity = entityMono.entity;
            }

            if (selectedEntity == Entity.Null)
            {
                Emote.SpawnEmoteText(slotOwner.center, RailLogisticsMod.EMOTE_CROWBAR_NOTHINGSELECTED);
                return;
            }

            if (interactPressed)
            {
                lastEntity = selectedEntity;
                Emote.SpawnEmoteText(slotOwner.center, RailLogisticsMod.EMOTE_CROWBAR_LINKSTARTED);
                return;
            }

            if (secondInteractPressed)
            {
                EntityManager entityManager = world.EntityManager;
                if (!entityManager.Exists(lastEntity)) return;

                if (selectedEntity == lastEntity)
                {
                    lastEntity = Entity.Null;
                    Emote.SpawnEmoteText(slotOwner.center, RailLogisticsMod.EMOTE_CROWBAR_LINKSAME);
                    return;
                }

                if (entityManager.HasComponent<MinecartJointCD>(selectedEntity))
                {
                    slotOwner.playerCommandSystem.LinkMinecarts(selectedEntity, lastEntity);
                    lastEntity = Entity.Null;
                    Emote.SpawnEmoteText(slotOwner.center, RailLogisticsMod.EMOTE_CROWBAR_LINKENDED);
                }
            }
        }

        public ObjectType GetSlotObjectType()
        {
            return EquipmentSlotModule.GetObjectType(CrowbarObjectType);
        }

        private ContainedObjectsBuffer AsBuffer(ObjectDataCD objectDataCd)
        {
            return new ContainedObjectsBuffer()
            {
                objectData = objectDataCd
            };
        }

        public void UpdateSlotVisuals(PlayerController controller)
        {
            ObjectDataCD objectDataCd = controller.GetHeldObject();
            ObjectInfo objectInfo = PugDatabase.GetObjectInfo(objectDataCd.objectID, objectDataCd.variation);

            ContainedObjectsBuffer objectsBuffer = AsBuffer(objectDataCd);

            controller.GetType()
                .GetMethod("ActivateCarryableItemSpriteAndSkin", BindingFlags.Instance | BindingFlags.NonPublic)
                .Invoke(controller, new object[]
                {
                    controller.carryablePlaceItemSprite,
                    controller.carryablePlaceItemPugSprite,
                    controller.carryableSwingItemSkinSkin,
                    objectInfo,
                    objectsBuffer
                });
            
            controller.carryablePlaceItemSprite.sprite = objectInfo.smallIcon;
            controller.carryablePlaceItemColorReplacer.UpdateColorReplacerFromObjectData(objectsBuffer);
        }
    }
}