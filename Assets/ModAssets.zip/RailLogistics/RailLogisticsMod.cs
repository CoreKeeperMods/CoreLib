using System.Collections.Generic;
using System.Reflection;
using CoreLib.Components;
using CoreLib.Submodules.EntityModule;
using CoreLib.Submodules.Equipment;
using CoreLib.Util;
using HarmonyLib;
using PugMod;
using RailLogistics.Components;
using RailLogistics.Patches;
using RailLogistics.Slots;
using RailLogistics.Systems;
using RailLogistics.UI;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using UnityEngine;
using Logger = RailLogistics.Logger;

[assembly: AssemblyVersion("1.0.0.0")]

public class RailLogisticsMod : IMod
{
	public const string MOD_ID = "RailLogistics";
	
	public static Emote.EmoteType EMOTE_CROWBAR_NOTHINGSELECTED;
	public static Emote.EmoteType EMOTE_CROWBAR_LINKSAME;
	public static Emote.EmoteType EMOTE_CROWBAR_LINKSTARTED;
	public static Emote.EmoteType EMOTE_CROWBAR_LINKENDED;

	public const int RPC_SET_LOCOMOTIVE_SPEED = 1;

	public static LocomotiveUI locomotiveUIPrefab;
	public static LocomotiveUI locomotiveUI;

	public void EarlyInit()
	{
		//harmony.PatchAll(typeof(EffectEventExtensions_Patch));
		//harmony.PatchAll(typeof(ConsoleCommands_Patch));
		BurstRuntime.LoadAdditionalLibrary($"{Application.streamingAssetsPath}/Mods/RailLogistics/RailLogistics_burst_generated.dll");

		EMOTE_CROWBAR_NOTHINGSELECTED = EquipmentSlotModule.RegisterTextEmote($"{MOD_ID}:Crowbar_NothingSelected");
		EMOTE_CROWBAR_LINKSAME = EquipmentSlotModule.RegisterTextEmote($"{MOD_ID}:Crowbar_LinkSame");
		EMOTE_CROWBAR_LINKSTARTED = EquipmentSlotModule.RegisterTextEmote($"{MOD_ID}:Crowbar_LinkStarted");
		EMOTE_CROWBAR_LINKENDED = EquipmentSlotModule.RegisterTextEmote($"{MOD_ID}:Crowbar_LinkEnded");
	}

	public void Init()
	{
		
        Logger.LogInfo("Rail Logistics Init");
        API.Server.OnWorldCreated += ServerWorldInit;

    }

	private void ServerWorldInit()
	{ 
		var world = API.Server.World;
		var system = world.CreateSystem<MinecartMoveSystem>();
		API.Server.AddScheduledSystem(system);
	}

	public void Shutdown()
    {
	    Logger.LogInfo("ExampleMod Shutdown");

    }

	public bool CanBeUnloaded() => false;
	
	public void Update()
	{
	}

	public void ModObjectLoaded(Object obj)
	{
		if (obj == null) return;
		
		Logger.LogInfo($"Loading: {obj.name}");
		if (!(obj is GameObject gameObject))
		{
			return;
		}

		var locomotive = gameObject.GetComponent<LocomotiveUI>();
		if (locomotive != null)
		{
			locomotiveUIPrefab = locomotive;
			return;
		}

		var objectAuthoring = gameObject.GetComponent<ObjectAuthoring>();
		var entityData = gameObject.GetComponent<EntityMonoBehaviourData>();
		if (objectAuthoring != null || entityData != null)
		{
			var objectType = gameObject.GetComponent<ModObjectTypeAuthoring>();
			if (objectType != null)
				objectType.Apply(objectAuthoring != null ? (MonoBehaviour)objectAuthoring : (MonoBehaviour)entityData);
			
			Logger.LogInfo($"Registering {gameObject.name} for authoring!");
			EntityModule.AddToAuthoringList(gameObject);
			API.Authoring.RegisterAuthoringGameObject(gameObject);
		}

		var slot = gameObject.GetComponent<EquipmentSlot>();

		if (slot != null)
		{
			EntityModule.AddToAuthoringList(gameObject);
			EquipmentSlotModule.RegisterEquipmentSlot<CrowbarEquipmentSlot>(gameObject);
		}
	}

	public void ObjectTypeAdded(Entity entity, GameObject authoringData, EntityManager entityManager)
	{
		var objectAuthoring = authoringData.GetComponent<EntityMonoBehaviourData>();
		if (objectAuthoring == null)
		{
			Logger.LogInfo("ObjectTypeAdded object null");
			return;
		}
		
		Logger.LogInfo($"ObjectTypeAdded id={objectAuthoring.objectInfo.objectID} type={objectAuthoring.objectInfo.objectType} name={objectAuthoring.name}");
    }

    public void MessageReceivedOnClient(int messageType, Entity entity, int value0, int value1)
	{
	}

	public void MessageReceivedOnServer(int messageType, Entity entity, int value0, int value1)
	{
		if (messageType == RPC_SET_LOCOMOTIVE_SPEED)
		{
			World world = API.Server.World;
			LocomotiveCD locomotiveCd = world.EntityManager.GetComponentData<LocomotiveCD>(entity);
			locomotiveCd.targetSpeed = value0;
			world.EntityManager.SetComponentData(entity, locomotiveCd);
		}
	}

	public static void OpenLocomotiveUI()
	{
		locomotiveUI.ShowContainerUI();
		Manager.ui.OnPlayerInventoryOpen();
	}
}
